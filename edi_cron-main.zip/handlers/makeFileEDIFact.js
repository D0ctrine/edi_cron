module.exports = () => {
    console.log('EDIFact Logic')
}