module.exports = () => {
    console.log('Xml Logic')
}