var fs = require('fs');

async function contentsGet(job) {
    // Maid DB 가져온다.
  let comsDB = await getDB(DB_TYPE='COMS');

    // Main Query 여러개 중에 가장 최근 데이터 가져오기
  let queryData = job.CFG_ID ? await comsDB.selectQuery(`
    SELECT *
    FROM (
            SELECT ROWNUM,A.*
            FROM QUERY_SETTING A
            WHERE SETTING_ID = :id AND TYPE='Main'
            ORDER BY ID DESC
        ) 
    WHERE ROWNUM='1'
  `,{id: job.CFG_ID}):'';
  // Binding 해야될 변수 가져오기 ( Common과 File_Define )
  let params = job.CFG_ID ? await comsDB.selectQuery(`
    SELECT * FROM (
        SELECT *
        FROM QUERY_SETTING
        WHERE 1=1
        AND SETTING_ID = (
            SELECT ID
            FROM CG_CUSTOMER 
            WHERE PARENT = (
                SELECT ID
                FROM CG_CUSTOMER 
                WHERE ID=(
                    SELECT PARENT
                    FROM CG_CUSTOMER 
                    WHERE ID=(
                        SELECT PARENT 
                        FROM CG_CUSTOMER 
                        WHERE ID=:id
                    )
                )
            )
            AND LOWER(NAME) = 'common'
        )
        AND TYPE IN ('DB','TEXT')
        AND KEY NOT IN (SELECT KEY
                        FROM QUERY_SETTING
                        WHERE 1=1
                        AND SETTING_ID = :id
                        AND TYPE IN ('DB','TEXT'))
        UNION ALL
        SELECT *
        FROM QUERY_SETTING
        WHERE 1=1
        AND SETTING_ID = :id
        AND TYPE IN ('DB','TEXT')
    )
    ORDER BY LENGTH(KEY) DESC
  `,{id: job.CFG_ID}):'';

  // let flatArrayJson = {};

  if (params.length > 0 && queryData.length > 0 && queryData[0].QUERY) {
    for (const param of params) {
        if(queryData[0].QUERY.indexOf(param.KEY)!==-1){
            let returnQuery = '';
            if (param.TYPE === 'DB') {
                let contentsDB = await getDB(DB_TYPE=param.DBTYPE);
                returnQuery = await contentsDB.selectQuery(param.QUERY,{});
                param.QUERY = await returnQuery.length>0?returnQuery[0].VALUE:'';
            } 
            queryData[0].QUERY = await queryData[0].QUERY.replace(new RegExp(':' + param.KEY, 'g'), param.QUERY)
            job.FILE_NAME = await job.FILE_NAME.replace(new RegExp(':' + param.KEY, 'g'), param.QUERY)
        } 
    }
  }
  let contentsData = 'Error Occured'
  if (job.CFG_ID && queryData.length > 0) {
    let contentsDB = await getDB(DB_TYPE=queryData[0].DBTYPE);
    //본문 가져오기
    contentsData = await contentsDB.selectQuery(queryData[0].QUERY, {});
  }
  

  return await {'contents': contentsData, 'filename': job.FILE_NAME};
}

// Oracle Connection 설정 ( COMS DB )
async function makeFileText(job) {
    //본문
    let returnData = await contentsGet(job);
    job.FILE_NAME = returnData.filename;
    returnData = returnData.contents;
    let Settings = await getDB(DB_TYPE='COMS');
    let contents = '';

    // env 값가져오기
    let envSettings = await Settings.selectQuery(`
    SELECT *
    FROM ENV_SETTING WHERE CFG_ID=:id
    `,{id: job.CFG_ID});

    // Header&Tail
    let HeadernTail = await Settings.selectQuery(`
    SELECT *
    FROM HEADNTAIL WHERE CFG_ID=:id
    `,{id: job.CFG_ID});

    // 본문에 Header 값 채우기
    for (const item of HeadernTail) {
        if (item.DATA_TYPE && item.DATA_TYPE.startsWith('h')) {
            if (item.DATA_TYPE.indexOf('sql') !== -1) {
                item.VALUE = await Settings.selectQuery(item.VALUE).then((returndata)=>{
                    return returndata.length > 0 ? returndata[0].VALUE + '\r\n':''
                });
                contents += item.VALUE
            } else {
                contents += item.VALUE + '\r\n'
            }
        } 
    }

    for (const item of returnData) {
        let start = ''
        let end = ''
        let beween = ''

        if (envSettings && envSettings.length>0) {
            start = await envSettings.find(element => element.ITEM==='start');
            end = await envSettings.find(element => element.ITEM==='end');
            between = await envSettings.find(element => element.ITEM==='between');
        }
        contents += start + Object.values(item).reduce((a,b)=>a + beween + b) + end
        contents += '\r\n'
    }
    // console.log(contents)

    // 본문에 Tail 값 채우기
    for (const item of HeadernTail) {
        if (item.DATA_TYPE && item.DATA_TYPE.startsWith('t')) {
            if (item.DATA_TYPE.indexOf('sql') !== -1) {
                item.VALUE = await Settings.selectQuery(item.VALUE).then((returndata)=>{
                    return returndata.length > 0 ? returndata[0].VALUE + '\r\n':''
                });
                contents += item.VALUE
            } else {
                contents += item.VALUE + '\r\n'
            }
        } 
    }

    // encoding :  "ascii" | "utf8" | "utf-8" | "utf16le" | "ucs2" | "ucs-2" | "base64" | "base64url" | "latin1" | "binary" | "hex"
    await fs.writeFile(job.FILE_NAME + '.' + job.FILE_TYPE, contents, job.FILE_CHARSET, function (err) {
        if (err) throw err;
        else console.log('ascii Results Received');
    });

     // ftp
     let ftp = await require('../db/main')
}

module.exports = (job) => {
    if (job.SEND_FLAG === 'Y') console.log('makeFileText(job)');
};

  async function getDB(DB_TYPE) {
      let connection = await '';
    if (DB_TYPE && DB_TYPE ==='COMS') {
        connection = await require('../db/main')
      } else if (DB_TYPE && DB_TYPE ==='MES') {
        connection = await require('../db/mes')
      } else if (DB_TYPE && DB_TYPE ==='REPORT') {
        connection = await require('../db/report')
      } else {
        return await false;
      }
      return await connection;
  }