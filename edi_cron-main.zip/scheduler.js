const cron = require('node-cron');
const { resolve } = require('path');

module.exports = {
    initCrons: (config) => {
        config.forEach(job => {
            if(cron.validate(job.frequency)){
                let task = cron.schedule(job.frequency, () => {
                    try {
                        let handler = '';
                        if (job.DATA_TYPE === 'text') {
                            handler = require(resolve('handlers/makeFileText'));
                            handler(job);
                        } else if (job.DATA_TYPE === 'xml') {
                            handler = require(resolve('handlers/makeFileXml'));
                            handler(job);
                        } else if (job.DATA_TYPE === 'edifact' ) {
                            handler = require(resolve('handlers/makeFileEDIFact'));
                            handler(job);
                        }
                    } catch (error) {
                        console.log(error);
                    }
                });
            }
        })
    }
}