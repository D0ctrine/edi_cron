var oracledb = require('oracledb');
var dotenv = require('dotenv');

//LOAD CONFIG
dotenv.config();

// Oracle Auto Commit 설정
oracledb.autoCommit = true;

// Oracle DB Return Data Type JSON
oracledb.outFormat = oracledb.OBJECT;

// Oracle Connection 설정 ( COMS DB )
async function SchedulerSetting() {
    let connection = await oracledb.getConnection({
        user: process.env.MAIN_DB_USER,
        password: process.env.MAIN_DB_PASSWORD,
        connectString: process.env.MAIN_DB_COMS
    });
    var resultList= await '';
    try {
        const sql = await connection.execute(`SELECT * FROM FILE_DEFINE WHERE SEND_FLAG='Y'`);
        resultList = await sql.rows
    } catch (err) {
        console.log(err);
    }
    await connection.close();
    let returnCronDefineList = [];
    
    for (let i=0; i<resultList.length; i++) {
        returnCronDefineList.push(await resultList[i])
        // test data
        // returnCronDefineList[i].frequency = '49 * * * * *'
        returnCronDefineList[i].frequency = '49 ' + resultList[i].SCHEDULE_MIN + ' ' + resultList[i].SCHEDULE_HOUR + ' ' + resultList[i].SCHEDULE_DAY + ' ' + resultList[i].SCHEDULE_MONTH + ' ' + resultList[i].SCHEDULE_WEEK
    }
    return returnCronDefineList;
}

module.exports = {
    SchedulerSetting
}

// SchedulerSetting List Format Example
// {
//     xmlFile: {
//         frequency: "* * * * *",
//         handler: "handlers/makeFileXml"
//     },
//     textFile: {
//         frequency: "* * * * *",
//         handler: "handlers/makeFileText"
//     },
//     EDIFactFile: {
//         frequency: "* * * * *",
//         handler: "handlers/makeFileEDIFact"
//     }
// };