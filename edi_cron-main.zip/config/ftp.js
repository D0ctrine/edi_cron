const ftp = require('basic-ftp')

async function connectFtp({FTP_ID, FILE_NAME}) {
    const client = new ftp.Client()
    client.ftp.verbose = true
    let ftpInfo = await getFtpData(FTP_ID)
    try {
        await client.access({
            host: ftpInfo.FTP_ADDR,
            user: ftpInfo.USER_ID,
            password: ftpInfo.PWD,
            secure: false
        })
        console.log(await client.list())
        await client.uploadFrom(FILE_NAME, ftpInfo.BASE_DIR + '/' + FILE_NAME)
        // await client.downloadTo(FILE_NAME, ftpInfo.BASE_DIR + '/' + FILE_NAME)
    }
    catch(err) {
        console.log(err)
    }
    client.close()
}

async function getFtpData(ftp_id) {
    let connection = await require('../db/main')
    let returnData = await connection.selectQuery(`
    SELECT * FROM FTP_SETTING WHERE ID=:id
    `,{id: ftp_id});
    return returnData.length > 0 ? returnData[0] : ''
}

module.exports = (ftpSettings) => {
    connectFtp(ftpSettings);
}