const config = require('./config');
const scheduler = require('./scheduler');
const cron = require('node-cron');

let today = new Date();   
today.setSeconds(today.getSeconds() + 2);  // 초
let seconds = today.getSeconds()

if(seconds != 50){
    let cronDefineList = '';
    config.SchedulerSetting().then((returnList)=>{
        cronDefineList = returnList;
        scheduler.initCrons(returnList);
    }).catch(error => console.log(error));
}

// 1분마다 설정해야될 정보 갱신 분이 바뀌기전 갱신
cron.schedule('50' + ' * * * * *', () => {
    config.SchedulerSetting().then((returnList)=>{
        cronDefineList = returnList;
        console.log(returnList)
        scheduler.initCrons(returnList);        
    }).catch(error => console.log(error));
})